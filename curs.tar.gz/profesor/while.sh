#!/usr/bin/bash

i=1

while 
	echo "i = $i"
	(( i < 10 ))
do
	echo $(( i * i++ ))
done
