#!/usr/bin/bash

for var in "$@"
do
	echo $var
done
echo La sfarsit lista este $@

