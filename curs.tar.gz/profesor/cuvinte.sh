#!/usr/bin/bash

echo -n "Introduceti o fraza: "
read fraza

set $fraza
echo Ati introdus $# cuvinte
