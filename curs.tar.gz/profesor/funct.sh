#!/usr/bin/bash

function asib
{
	a=100
	declare b=400
	echo a este $a si b este $b
}

a=10
b=40
echo Inainte de functie a este $a si b este $b
asib
echo Dupa functie a este $a si b este $b

