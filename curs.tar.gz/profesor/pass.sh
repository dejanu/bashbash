#!/usr/bin/bash

i=1
ps -f

cat /etc/passwd | while read line
do
	echo "$i:$line"
	let i=i+1
	ps -f
done 

echo $i
