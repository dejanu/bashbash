#!/usr/bin/bash

number=$(( RANDOM % 10 ))
ghici=1

until 
	echo -n "Introduceti un numar intre 0 si 9: "
	read n
	(( n == number ))
do
	echo NU ati ghicit 
	let ghici=ghici+1
done

echo Ati ghicit din $ghici incercari
