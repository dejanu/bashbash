ps -f
