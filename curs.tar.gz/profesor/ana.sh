#!/usr/bin/bash

function recursiv
{	
	if [[ $# -gt 0 ]]
	then
		declare cuvant=$1
		shift
		recursiv "$@"
		echo $cuvant
	else
		return 0
	fi
}


echo -n "Introduceti o fraza: "
read fraza

recursiv $fraza
