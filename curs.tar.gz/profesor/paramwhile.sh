#!/usr/bin/bash

orig_params="$@"


while [[ $# -gt 0 ]]
do
	echo $1
	shift
done
set $orig_params
echo La sfarsit lista este $@
